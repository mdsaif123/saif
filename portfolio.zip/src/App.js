import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import HeroSection from './components/HeroSection/HeroSection';
import Services from './components/Services/Services';
import Footer from './components/Footer/Footer';
// import Resume from './components/Resume/Resume';

function App() {
  return (
  <>
  <Navbar/>
  <HeroSection/>
  <Services/>
  <Footer/>
  {/* <Resume/> */}

  </>
  );
}

export default App;
