import React from 'react'
import "./Service.css"

const Services = () => {
  return (
    <div className='container text-white my-5 service-container'>
    <div className="text-center"></div>
    <h1 className='service-title'> Services</h1>
    <div className="row">
        <div className="col-md-6 my-3">
        <div className="card">
            <div className="card-body">
            <h3>API Integration</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae rem, facere, laborum libero incidunt obcaecati expedita ullam fuga veniam eveniet id, nihil assumenda soluta accusamus.</p>
            </div>
        </div>
           
        </div>
        <div className="col-md-6 my-3">
        <div className="card">
            <div className="card-body">
            <h3>Frontend Developemnt</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae rem, facere, laborum libero incidunt obcaecati expedita ullam fuga veniam eveniet id, nihil assumenda soluta accusamus.</p>
            </div>
        </div>
        
        </div>
        <div className="col-md-6 my-3">
        <div className="card">
            <div className="card-body">
            <h3>Backend Development</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae rem, facere, laborum libero incidunt obcaecati expedita ullam fuga veniam eveniet id, nihil assumenda soluta accusamus.</p>
            </div>
        </div>
       
        </div>
        <div className="col-md-6 my-3">
        <div className="card">
            <div className="card-body">
            <h3>Full Stack Web Developemnt</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae rem, facere, laborum libero incidunt obcaecati expedita ullam fuga veniam eveniet id, nihil assumenda soluta accusamus.</p>
            </div>
        </div>
       
        </div>
    </div>
      
    </div>
  )
}

export default Services
