import React from "react";
import "./HeroSection.css";
import p1 from "../../assets/images/p1.png";

const HeroSection = () => {
  return (
    <>
      <div className="container my-2 hero-section-con">
        <div className="row">
          <div className="col-md-6">
            <div className="container d-flex justify-content-between align-items-center mt-5">
              <div className="hero-text text-white">
                <p className="hero-title mb-0">Software Developer</p>
                <h1 className="hero-intro display-3">Hello I’m</h1>
                <h1 className="hero-name  display-2">
                  Md <span className="s">S</span>aif<i className="ri-sailboat-fill"></i>
                </h1>

                <p className="hero-description">
                  I excel at crafting elegant digital experiences and I am
                  proficient in various programming languages and technologies.
                </p>
                <div className="hero-buttons d-flex justify-content-start">
                  <button class="btn-download">
                    <span>Download CV</span>
                  </button>
                  <button className=" btn-icon">A</button>
                  <button className=" btn-icon">B</button>
                  <button className=" btn-icon">C</button>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <img style={{ width: "350px" }} src={p1} alt="" />
          </div>
        </div>
        <div className="row  text-white">
        {/* Column 1 */}
        <div className="col-md-3 col-6">
          <div className="d-flex justify-content-center align-items-center">
            <h1 className="display-3 fw-bold me-2 numbers">6</h1>
            <div>
              <p className="mb-0">Months of</p>
              <p className="mb-0">Experience</p>
            </div>
          </div>
        </div>

        {/* Column 2 */}
        <div className="col-md-3 col-6">
          <div className="d-flex justify-content-center align-items-center">
            <h1 className="display-3 fw-bold me-2 numbers">10</h1>
            <div className="text-start">
              <p className="mb-0 text-secondary">Projects</p>
              <p className="mb-0 text-secondary">Completed</p>
            </div>
          </div>
        </div>

        {/* Column 3 */}
        <div className="col-md-3 col-6">
          <div className="d-flex justify-content-center align-items-center">
            <h1 className="display-3 fw-bold me-2 numbers">8</h1>
            <div className="text-start">
              <p className="mb-0">Technologies</p>
              <p className="mb-0">Mastered</p>
            </div>
          </div>
        </div>

        {/* Column 4 */}
        <div className="col-md-3 col-6">
          <div className="d-flex justify-content-center align-items-center">
            <h1 className="display-3 fw-bold me-2 numbers">50</h1>
            <div className="text-start">
              <p className="mb-0">Code</p>
              <p className="mb-0">Commits</p>
            </div>
          </div>
        </div>
      </div>
        </div>
      
    </>
  );
};

export default HeroSection;
